# STUDIO SITES

Construtor de sites com IA local, feito para funcionar como site estático e ser publicado no GitHub Pages.

## Publicação
1. Copie o conteúdo desta pasta para o repositório publicado pelo GitHub Pages.
2. Mantenha `index.html` na raiz.
3. Mantenha a pasta `assets/` e o arquivo `.nojekyll`.
4. Aguarde a publicação do GitHub Pages e faça uma atualização completa do navegador.

## Arquitetura
- HTML-first: a primeira interface existe sem depender de inicialização JS.
- CSS local/embutido: a aparência não depende de Google Fonts ou CDN.
- JavaScript puro: IA local por regras, vocabulário, sinônimos e contexto.
- localStorage: projetos, conversa e histórico ficam no navegador.
- `assets/models-600.json`: biblioteca local de 600 modelos.
- SVGs gerados localmente: visuais adequados à categoria sem API de imagens.
- Exportações: ZIP e PDF gerados no próprio navegador.

## Fluxo principal
Usuário → conversa com IA → site criado → preview real → novas alterações → undo/redo → ZIP/PDF.
