(() => {
"use strict";
const $ = (s,el=document)=>el.querySelector(s), $$=(s,el=document)=>[...el.querySelectorAll(s)];
const KEY="studio-sites-v1";
const uid=()=>Math.random().toString(36).slice(2,9);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const slug=s=>String(s||"site").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"site";
const defaults={name:"Seu negócio",category:"negócio",style:"Elegant",title:"Seu próximo site começa aqui",subtitle:"Uma presença digital criada para apresentar seu negócio com clareza, personalidade e profissionalismo.",bg:"light",accent:"#111318",showPrices:true,showImages:true,whatsapp:"",instagram:"",facebook:"",tiktok:"",youtube:"",telegram:"",threads:"",x:"",linkedin:"",pinterest:"",discord:"",email:"",phone:"",address:"",customLink:"",sections:["products","about","testimonials","contact"],productCount:3,projectId:null};
let state=load();
let catalogCache=null;
let catalogPage=1;
let catalogQuery="";
let catalogCategory="Todos";
function load(){try{let x=JSON.parse(localStorage.getItem(KEY));return x&&x.projects?x:{projects:[],current:null,history:[],future:[],messages:[]}}catch{return {projects:[],current:null,history:[],future:[],messages:[]}}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){console.error("Studio Sites: falha ao salvar localmente",e)}}
function fresh(){return {...defaults,projectId:uid()}}
function current(){return state.projects.find(p=>p.id===state.current)||state.projects[0]||null}
function pushHistory(){const p=current();if(!p)return;state.history.push(JSON.stringify(p));if(state.history.length>40)state.history.shift();state.future=[];save()}
function addProject(p){state.projects.unshift(p);state.current=p.id;state.history=[];state.future=[];save()}
function toast(t){let x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),2600)}
function whatsapp(n,msg=""){let d=String(n||"").replace(/\D/g,"");if(d.startsWith("0"))d=d.slice(1);if(d.length===11)d="55"+d;else if(d.length===10)d="55"+d;return d?`https://wa.me/${d}${msg?`?text=${encodeURIComponent(msg)}`:""}`:""}
function inferCategory(t){
 t=t.toLowerCase();
 const map=[["pizzaria",/pizza|pizaria|pizzariaa/],["hamburgueria",/hamb[uú]rg|burger/],["restaurante",/restaurante|bistr[oô]|gastronomia/],["clínica",/cl[ií]nica|consult[oó]rio|dentista|est[eé]tica/],["barbearia",/barbearia|barbeiro/],["mercado",/mercado|supermercado|mercearia/],["loja de roupas",/roupa|moda|boutique/],["fotógrafo",/fot[oó]grafo|fotografia/],["academia",/academia|fitness|gym/],["salão de beleza",/sal[aã]o|cabeleireiro|beleza/]];
 return map.find(x=>x[1].test(t))?.[0]||null
}
function normalize(t){return t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\bpizaria\b/g,"pizzaria").replace(/pizzariaa/g,"pizzaria").replace(/renover/g,"remover").replace(/\bwhats\b|\bzap\b/g,"whatsapp").replace(/\bimg[s]?\b/g,"imagens").replace(/\bpreco[s]?\b/g,"preços")}
function applyAI(raw){
 let text=normalize(raw.trim()), p=current();
 if(!p){p=fresh();addProject(p);p=current()}
 pushHistory();
 let changed=[], cat=inferCategory(text);
 if(cat){p.category=cat; if(!p.name||p.name==="Seu negócio")p.name=cat.charAt(0).toUpperCase()+cat.slice(1); changed.push("tipo do site")}
 const nm=text.match(/(?:muda|troca)\s+o\s+nome\s+(?:para|pra|por)\s+["“]?([^"”\n,.]+)["”]?|(?:nome)\s+(?:para|é|e)\s+["“]?([^"”\n,.]+)["”]?|(?:chama(?:-se)?|nome da (?:pizzaria|hamburgueria|empresa|loja))\s*[:=]?\s*["“]?([^"”\n,.]+)["”]?/i);
 if(nm){p.name=(nm[1]||nm[2]||nm[3]).trim();changed.push("nome")}
 const wa=text.match(/(?:whatsapp|wpp|zap)[^0-9]{0,30}(\d[\d\s().-]{9,18}\d)/i);
 if(wa){p.whatsapp=wa[1].replace(/\D/g,"");changed.push("WhatsApp")}
 const phone=text.match(/(?:telefone|numero|número)[^0-9]{0,20}(\d[\d\s().-]{9,18}\d)/i);
 if(phone&&!/(whatsapp|wpp|zap)/.test(text)){p.phone=phone[1].replace(/\D/g,"");changed.push("telefone")}
 const email=text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
 if(email){p.email=email[0];changed.push("e-mail")}
 const addr=text.match(/(?:endereço|endereco|localização|localizacao)[^:=-]{0,15}[:=-]?\s+(.{5,100})$/i);
 if(addr&&!/(remove|tira|sem)/.test(text)){p.address=addr[1].trim().replace(/[.]+$/,"");changed.push("localização")}
 const ig=text.match(/(?:instagram|ig)[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,40})/i);
 if(ig && !/remove|tira|sem/.test(text)){p.instagram=ig[1];changed.push("Instagram")}
 if(/remove|tira|sem/.test(text)&&/instagram|ig/.test(text)){p.instagram="";changed.push("Instagram removido")}
 const socialRules=[["facebook",/(?:facebook|face)[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["tiktok",/tiktok[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["youtube",/youtube[^@\w]{0,20}(?:@)?([a-zA-Z0-9._-]{2,60})/i],["telegram",/telegram[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["threads",/threads[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["x",/(?:x|twitter)[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["linkedin",/linkedin[^@\w]{0,20}([a-zA-Z0-9._-]{2,70})/i],["pinterest",/pinterest[^@\w]{0,20}@?([a-zA-Z0-9._-]{2,50})/i],["discord",/discord[^@\w]{0,20}([a-zA-Z0-9._-]{2,80})/i]];
 socialRules.forEach(([key,re])=>{const m=text.match(re);if(m&&!/(remove|tira|sem)/.test(text)){p[key]=m[1];changed.push(key)}});
 if(/remove|tira|sem/.test(text)&&/pre[cç]os?/.test(text)){p.showPrices=false;changed.push("preços removidos")}
 if(/(?:coloca|bota|p[oõ]e|adiciona|com|com )[^.\n]{0,30}pre[cç]os?/.test(text)){p.showPrices=true;changed.push("preços")}
 if(/remove|tira|sem/.test(text)&&/imag|foto/.test(text)){p.showImages=false;changed.push("imagens removidas")}
 if(/(?:coloca|bota|p[oõ]e|adiciona|com|fotos?)/.test(text)&&/imag|foto/.test(text)){p.showImages=true;changed.push("imagens")}
 if(/fundo preto|fundao preto|fundo escuro|fundao escuro|dark/.test(text)){p.bg="dark";changed.push("fundo escuro")}
 if(/fundo branco|fundo claro/.test(text)){p.bg="light";changed.push("fundo claro")}
 if(/fundo.*pizza|pizza.*fundo/.test(text)){p.bg="food";changed.push("fundo temático")}
 if(/premium|luxuoso|luxuosa|sofisticado|sofisticada|elegante|chique/.test(text)){p.style="Elegant";changed.push("estilo premium")}
 if(/minimalista|minimal/.test(text)){p.style="Minimal";changed.push("estilo minimal")}
 if(/moderno|moderna/.test(text)){p.style="Bold";changed.push("estilo moderno")}
 if(/fonte.*(moderna|clean|limpa)|tipografia.*moderna/.test(text)){p.style="Minimal";changed.push("tipografia moderna")}
 if(/remove|tira/.test(text)&&/depoimento/.test(text)){p.sections=p.sections.filter(x=>x!=="testimonials");changed.push("depoimentos removidos")}
 if(/(?:adiciona|coloca|bota).{0,25}depoimento/.test(text)&&!p.sections.includes("testimonials")){p.sections.push("testimonials");changed.push("depoimentos")}
 if(/(?:adiciona|coloca|bota).{0,25}(?:sobre|sobre n[oó]s)/.test(text)&&!p.sections.includes("about")){p.sections.push("about");changed.push("Sobre nós")}
 if(/(?:remove|tira).{0,25}(?:sobre|sobre n[oó]s)/.test(text)){p.sections=p.sections.filter(x=>x!=="about");changed.push("Sobre nós removido")}
 if(/(?:adiciona|coloca|bota).{0,25}(?:galeria)/.test(text)&&!p.sections.includes("gallery")){p.sections.push("gallery");changed.push("galeria")}
 if(/(?:remove|tira).{0,25}galeria/.test(text)){p.sections=p.sections.filter(x=>x!=="gallery");changed.push("galeria removida")}
 if(/(?:adiciona|coloca|bota).{0,25}(?:contato|contact)/.test(text)&&!p.sections.includes("contact")){p.sections.push("contact");changed.push("contato")}
 if(/(?:remove|tira).{0,25}(?:contato|contact)/.test(text)){p.sections=p.sections.filter(x=>x!=="contact");changed.push("contato removido")}
 if(/sem telefone|remove.{0,20}telefone|tira.{0,20}telefone/.test(text))p.phone="";
 if(/sem whatsapp|remove.{0,20}whatsapp|tira.{0,20}whatsapp/.test(text)){p.whatsapp="";changed.push("WhatsApp removido")}
 if(/sem instagram|remove.{0,20}instagram|tira.{0,20}instagram/.test(text)){p.instagram="";changed.push("Instagram removido")}
 ["facebook","tiktok","youtube","telegram","threads","x","linkedin","pinterest","discord"].forEach(k=>{if(new RegExp(`(?:sem|remove|tira).{0,20}${k}`).test(text)&&p[k]){p[k]="";changed.push(`${k} removido`)}});
 if(/tr[eê]s produtos|3 produtos/.test(text))p.productCount=3;
 if(/cinco produtos|5 produtos/.test(text))p.productCount=5;
 if(/quatro produtos|4 produtos/.test(text))p.productCount=4;
 if(/dois produtos|2 produtos/.test(text))p.productCount=2;
 p.lastPrompt=raw;p.updatedAt=new Date().toISOString();save();render();
 return changed.length?`Pronto — ajustei ${changed.join(", ")}.`:`Entendi o pedido e atualizei a composição do site para combinar com o que você descreveu.`;
}
function siteData(p){
 const c=p.category;
 const presets={
  pizzaria:["Forno & Massa","Pizzas artesanais, massa de fermentação lenta e sabores que ficam na memória.","Nossas pizzas","Margherita da casa","Calabresa especial","Quatro queijos"],
  hamburgueria:["Burger House","Hambúrguer artesanal, ingredientes selecionados e uma experiência urbana feita para você.","Destaques do cardápio","Classic Burger","Bacon Smash","House Special"],
  restaurante:["Casa Aurora","Cozinha contemporânea, ingredientes frescos e uma experiência acolhedora.","Pratos em destaque","Prato da Casa","Risoto artesanal","Menu Aurora"],
  barbearia:["Studio Barber","Corte, barba e cuidado masculino em um ambiente moderno e cheio de personalidade.","Serviços","Corte clássico","Barba completa","Corte + Barba"],
  clínica:["Clínica Essenza","Atendimento cuidadoso, ambiente acolhedor e uma experiência pensada para você.","Especialidades","Atendimento personalizado","Equipe especializada","Estrutura moderna"],
  mercado:["Mercado Central","Tudo o que você precisa para sua casa, perto de você, com praticidade e qualidade.","Ofertas e categorias","Hortifruti","Mercearia","Bebidas e conveniência"],
  "loja de roupas":["Atelier Studio","Moda contemporânea, curadoria autoral e peças para expressar seu estilo.","Coleção em destaque","Essenciais","Novidades","Seleção Studio"],
  fotógrafo:["Studio Visual","Fotografia com direção criativa, olhar autoral e imagens que contam histórias.","Portfólio","Retratos","Eventos","Ensaios"],
  academia:["Move Fitness","Treinos, energia e acompanhamento para transformar sua rotina em movimento.","Treinos","Musculação","Funcional","Personal"],
  "salão de beleza":["Studio Beauty","Beleza, cuidado e estilo em uma experiência pensada nos mínimos detalhes.","Serviços","Cabelo","Unhas","Beleza e estética"]
 };
 return presets[c]||[p.name||"Studio Sites","Uma experiência digital profissional criada para apresentar sua marca.","Soluções em destaque","Serviço principal","Experiência personalizada","Atendimento especial"];
}
function imageSvg(category,variant=1){
 const palettes={
  pizzaria:["#ff7a45","#4b1710","🍕"],hamburgueria:["#ffb84d","#32160b","🍔"],restaurante:["#d7a86e","#1b1814","🍽"],
  clínica:["#7ee0d1","#123a3a","✚"],barbearia:["#b89a72","#19130e","✂"],mercado:["#8ed26c","#16351a","✦"],
  "loja de roupas":["#d9b7ff","#24153a","◆"],fotógrafo:["#8eb7ff","#101c39","◉"],academia:["#ff5d72","#38101a","⚡"],"salão de beleza":["#f2a7c8","#3a1628","✦"]
 };
 const q=palettes[category]||["#8b7cff","#15102d","✦"], shift=(Number(variant)||1)*17;
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 620"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${q[0]}"/><stop offset="1" stop-color="${q[1]}"/></linearGradient><filter id="b"><feGaussianBlur stdDeviation="28"/></filter></defs><rect width="900" height="620" fill="url(#g)"/><circle cx="130" cy="110" r="150" fill="rgba(255,255,255,.12)" filter="url(#b)"/><circle cx="760" cy="520" r="210" fill="rgba(0,0,0,.18)" filter="url(#b)"/><g fill="rgba(255,255,255,.92)" font-family="Arial,sans-serif"><text x="70" y="105" font-size="22" font-weight="700" letter-spacing="3">STUDIO SITES</text><text x="70" y="350" font-size="150">${q[2]}</text><text x="70" y="500" font-size="28" font-weight="700">Experiência visual ${String((shift%9)+1).padStart(2,"0")}</text></g></svg>`;
}
function imageUri(category,variant=1){return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(imageSvg(category,variant))}`}
function imageFor(p,variant=1){return imageUri(p.category,variant)}
function socialHref(key,value){const v=String(value||"").replace(/^@/,"");const map={instagram:`https://instagram.com/${v}`,facebook:`https://facebook.com/${v}`,tiktok:`https://tiktok.com/@${v}`,youtube:`https://youtube.com/@${v}`,telegram:`https://t.me/${v}`,threads:`https://threads.net/@${v}`,x:`https://x.com/${v}`,linkedin:`https://linkedin.com/in/${v}`,pinterest:`https://pinterest.com/${v}`,discord:v.startsWith("http")?v:"https://discord.com/users/"+v};return map[key]||v}

function renderSite(p){
 const d=siteData(p), dark=p.bg==="dark", food=p.bg==="food";
 let style= p.style==="Minimal" ? {bg:dark?"#111":"#fff",surface:dark?"#191919":"#f7f7f5",text:dark?"#fff":"#151515",muted:dark?"#b8b8b8":"#68707b",accent:"#111318",line:dark?"#333":"#e3e3e3"} :
 p.style==="Bold" ? {bg:dark?"#101010":"#f7f5ef",surface:dark?"#1a1a1a":"#fff",text:dark?"#fff":"#161616",muted:"#777",accent:"#d45a27",line:"#dedbd5"} :
 {bg:dark?"#121212":"#fff",surface:dark?"#1b1b1b":"#f6f6f4",text:dark?"#fff":"#151515",muted:dark?"#b5b5b5":"#68707b",accent:food?"#a84c22":"#111318",line:dark?"#333":"#e3e3e3"};
 let sections="";
 if(p.sections.includes("products"))sections+=`<section class="site-section alt"><h2>${esc(d[3])}</h2><p>Seleção preparada com cuidado para entregar qualidade em cada detalhe.</p><div class="site-grid">${Array.from({length:p.productCount||3},(_,i)=>`<article class="site-card">${p.showImages?`<div class="card-image"><img loading="lazy" src="${imageFor(p,i+2)}" alt="${esc(d[4+i%3])}"></div>`:""}<div class="card-body"><h3>${esc(d[4+i%3])}</h3><p>Uma escolha especial da nossa casa, feita para surpreender.</p>${p.showPrices?`<div class="site-price">Confira no atendimento</div>`:""}</div></article>`).join("")}</div></section>`;
 if(p.sections.includes("about"))sections+=`<section class="site-section"><h2>Sobre ${esc(p.name)}</h2><p>Uma marca construída com atenção aos detalhes, qualidade e uma experiência que começa no primeiro contato.</p></section>`;
 if(p.sections.includes("gallery")&&p.showImages)sections+=`<section class="site-section alt"><h2>Galeria</h2><p>Uma seleção visual para apresentar a atmosfera da marca.</p><div class="site-grid">${[4,5,6].map(i=>`<div class="card-image"><img loading="lazy" src="${imageFor(p,i)}" alt="Galeria de ${esc(p.name)}"></div>`).join("")}</div></section>`;
 if(p.sections.includes("testimonials"))sections+=`<section class="site-section"><h2>Quem conhece, recomenda</h2><p>Experiências reais que ajudam a construir confiança.</p><div class="testimonials"><div class="quote"><p>“Atendimento excelente e uma experiência impecável.”</p><b>Cliente Studio</b></div><div class="quote"><p>“Tudo muito bem pensado, do primeiro contato ao resultado.”</p><b>Cliente Studio</b></div><div class="quote"><p>“Profissionalismo e qualidade em cada detalhe.”</p><b>Cliente Studio</b></div></div></section>`;
 if(p.sections.includes("contact")){const socials=[p.instagram?`<b>Instagram</b><a href="${esc(socialHref("instagram",p.instagram))}" target="_blank" rel="noopener">@${esc(p.instagram)}</a>`:"",p.facebook?`<b>Facebook</b><a href="${esc(socialHref("facebook",p.facebook))}" target="_blank" rel="noopener">${esc(p.facebook)}</a>`:"",p.tiktok?`<b>TikTok</b><a href="${esc(socialHref("tiktok",p.tiktok))}" target="_blank" rel="noopener">@${esc(p.tiktok)}</a>`:"",p.youtube?`<b>YouTube</b><a href="${esc(socialHref("youtube",p.youtube))}" target="_blank" rel="noopener">${esc(p.youtube)}</a>`:"",p.telegram?`<b>Telegram</b><a href="${esc(socialHref("telegram",p.telegram))}" target="_blank" rel="noopener">@${esc(p.telegram)}</a>`:"",p.email?`<b>E-mail</b><a href="mailto:${esc(p.email)}">${esc(p.email)}</a>`:"",p.phone?`<b>Telefone</b><span>${esc(p.phone)}</span>`:"",p.address?`<b>Localização</b><span>${esc(p.address)}</span>`:""].filter(Boolean).join("");sections+=`<section class="site-section alt"><div class="site-contact"><div><h2 style="text-align:left">Vamos conversar?</h2><p style="text-align:left;margin-left:0">Entre em contato para saber mais.</p></div><div class="contact-box">${p.whatsapp?`<b>WhatsApp</b><a href="${esc(whatsapp(p.whatsapp))}" target="_blank" rel="noopener">${esc(p.whatsapp)}</a>`:""}${socials||(!p.whatsapp?`<span>Adicione seus contatos conversando com a IA.</span>`:"")}</div></div></section>`;}
 const image=p.showImages?`<div class="site-visual"><img loading="eager" src="${imageFor(p,1)}" alt="Imagem de ${esc(d[0])}"><div class="visual-label">${esc(d[0])}</div></div>`:"";
 return `<div class="site-preview" style="--site-bg:${style.bg};--site-surface:${style.surface};--site-text:${style.text};--site-muted:${style.muted};--site-accent:${style.accent};--site-line:${style.line};--site-card:${dark?"#191919":"#fff"}"><header class="site-header"><div class="site-logo">${esc(p.name||d[0])}</div><nav class="site-nav"><span>Início</span><span>Sobre</span><span>Serviços</span>${p.sections.includes("contact")?"<span>Contato</span>":""}</nav>${p.whatsapp?`<a class="site-cta" href="${esc(whatsapp(p.whatsapp))}" target="_blank" rel="noopener">WhatsApp</a>`:""}</header><main class="site-main"><section class="site-hero"><div><h1>${esc(d[0])}</h1><p>${esc(d[1])}</p><div class="site-actions">${p.whatsapp?`<a class="site-btn" href="${esc(whatsapp(p.whatsapp))}" target="_blank" rel="noopener">Falar no WhatsApp</a>`:""}<button class="site-btn alt">Conheça</button></div></div>${image}</section>${sections}</main><footer class="site-footer"><span>© ${new Date().getFullYear()} ${esc(p.name||d[0])}</span><span>${p.instagram?"@"+esc(p.instagram):"Presença digital criada com Studio Sites"}</span></footer></div>`;
}
function addMsg(role,text){state.messages=state.messages||[];state.messages.push({role,text});if(state.messages.length>80)state.messages.shift();save()}
function messagesHTML(){return (state.messages||[]).map(m=>`<div class="bubble ${m.role}">${esc(m.text)}</div>`).join("")}
function page(view="home"){
 const active=view;
 return `<header class="topbar"><div class="logo">STUDIO SITES</div><nav class="nav" aria-label="Navegação principal">${[["home","Início"],["creator","Criar com IA"],["projects","Projetos"],["templates","Modelos"]].map(([x,l])=>`<button data-nav="${x}" class="${active===x?"active":""}">${l}</button>`).join("")}</nav><div class="top-actions"><button class="btn ghost mobile-menu" data-action="mobile-nav">☰</button><button class="btn primary" data-action="new">Criar site</button></div></header><main id="main"></main>`;
}
function renderHome(){
 $("#main").innerHTML=`
 <section class="hero"><div><span class="eyebrow"><span class="pulse"></span> Criação por IA, local e sem API</span><h1>Crie sites profissionais <span>conversando com IA.</span></h1><p>Descreva o que você imagina e o STUDIO SITES transforma sua ideia em uma experiência completa — estrutura, conteúdo, visual e ajustes em tempo real.</p><div class="hero-actions"><button class="btn primary" data-action="new">Começar agora <span>→</span></button><button class="btn ghost" data-nav="templates">Explorar modelos</button></div><div class="hero-note"><b>● IA local</b><span>Sem API Key</span><span>•</span><span>Salvo neste dispositivo</span></div></div><div class="hero-art"><div class="glow"></div><div class="art-browser"><div class="art-top"><i class="dot"></i><i class="dot"></i><i class="dot"></i><div class="art-address">studio-sites.local / preview</div></div><div class="art-site"><div class="art-brand">STUDIO SITES AI</div><h3>Uma ideia.<br>Um site completo.</h3><p>A IA interpreta seu pedido e cria uma interface profissional pronta para você editar e publicar.</p><div class="fake-cards"><div class="fake-card"></div><div class="fake-card"></div><div class="fake-card"></div></div></div></div></div></section>
 <section class="section"><div class="section-head"><div><div class="section-kicker">Como funciona</div><h2>Você fala. A IA constrói.</h2><p>Não é um gerador de prompts. É um construtor visual: você pede, vê o resultado e continua conversando.</p></div></div><div class="feature-grid"><div class="feature"><div class="feature-icon">01</div><h3>Descreva do seu jeito</h3><p>“Cria uma pizzaria moderna, escura, com fotos grandes e WhatsApp.” A IA entende português natural, gírias e erros de digitação.</p></div><div class="feature"><div class="feature-icon">02</div><h3>Refine conversando</h3><p>“Tira os preços”, “deixa premium”, “adiciona depoimentos”. Cada comando altera o site real no preview.</p></div><div class="feature"><div class="feature-icon">03</div><h3>Exporte quando quiser</h3><p>Desfaça, refaça, salve localmente e baixe o site ou uma apresentação em PDF.</p></div></div></section>
 <section class="section"><div class="section-head"><div><div class="section-kicker">IA + Preview</div><h2>Um editor que responde ao que você fala.</h2><p>O chat e o site ficam lado a lado para você enxergar cada mudança.</p></div><button class="btn primary" data-action="new">Criar um site</button></div><div class="feature live-demo"><div><div class="bubble user" style="display:inline-block">cria uma hamburgueria moderna sem preços, fundo escuro e fotos grandes</div><div class="bubble ai" style="margin-top:10px">Pronto — criei a estrutura e apliquei o estilo. Agora você pode pedir qualquer ajuste.</div></div><div class="art-browser" style="transform:none"><div class="art-top"><i class="dot"></i><i class="dot"></i><i class="dot"></i><div class="art-address">preview.studio-sites</div></div><div class="art-site" style="min-height:220px"><div class="art-brand">BURGER HOUSE</div><h3 style="margin-top:32px;font-size:25px">Sabor forte.<br>Design forte.</h3><div class="fake-cards"><div class="fake-card" style="height:65px"></div><div class="fake-card" style="height:65px"></div><div class="fake-card" style="height:65px"></div></div></div></div></div></section>`;
}
function renderCreator(){
 let p=current();
 if(!p){p=fresh();addProject(p);addMsg("ai","Olá! Eu sou a IA do Studio Sites. Descreva o site que você quer criar — pode falar do seu jeito.");}
 $("#main").innerHTML=`<section class="creator"><div class="panel chat"><div class="panel-head"><div><div class="panel-title">Criar com IA</div><div class="status"><i></i> IA local ativa</div></div><button class="iconbtn" data-action="clear-chat">Limpar</button></div><div class="messages" id="messages">${messagesHTML()}</div><div class="composer"><div class="suggestions"><button class="chip" data-prompt="cria uma pizzaria moderna sem preços, com fotos bonitas, fundo escuro e botão de whatsapp">Pizzaria moderna</button><button class="chip" data-prompt="cria uma hamburgueria moderna, escura, com fotos grandes">Hamburgueria</button><button class="chip" data-prompt="deixa mais premium e elegante">Mais premium</button></div><textarea id="prompt" placeholder="Descreva o site que você quer..."></textarea><div class="composer-row"><button class="btn ghost" data-action="undo">↶</button><button class="btn ghost" data-action="redo">↷</button><button class="btn primary" data-action="send">Criar / alterar</button></div></div></div><div class="panel preview-panel"><div class="preview-toolbar"><b>Preview</b><span class="status" style="margin-left:8px"><i></i> Atualizado</span><span class="spacer"></span><button class="iconbtn" data-action="download-zip">Baixar ZIP</button><button class="iconbtn" data-action="pdf">Baixar PDF</button><button class="iconbtn" data-action="fullscreen">Tela cheia</button></div><div class="site-frame" id="site-frame">${renderSite(p)}</div></div></section>`;
 $("#messages").scrollTop=999999;
}
function renderProjects(){
 $("#main").innerHTML=`<section class="section"><div class="section-head"><div><h2>Projetos</h2><p>Seus sites ficam salvos localmente neste navegador.</p></div><button class="btn primary" data-action="new">Novo projeto</button></div><div class="projects-grid">${state.projects.length?state.projects.map(p=>`<article class="project-card"><div class="project-thumb"><small>${esc(p.category)}</small><h3>${esc(p.name)}</h3></div><div class="project-info"><p>Atualizado ${new Date(p.updatedAt||Date.now()).toLocaleDateString("pt-BR")}</p><button class="btn primary" data-open="${p.id}">Abrir no editor</button></div></article>`).join(""):`<div class="feature" style="grid-column:1/-1"><h3>Nenhum projeto ainda</h3><p>Comece descrevendo o site que você quer.</p><button class="btn primary" data-action="new" style="margin-top:15px">Criar meu primeiro site</button></div>`}</div></section>`;
}
const templateNames=["Classic","Split","Minimal","Dark","Glass","Magazine","Rounded","Elegant","Bold","Compact"];
async function getCatalog(){
 if(catalogCache)return catalogCache;
 try{const r=await fetch("assets/models-600.json",{cache:"no-store"});if(!r.ok)throw new Error("catalog");catalogCache=await r.json();}catch(e){catalogCache=Array.from({length:600},(_,i)=>({id:`modelo-${i+1}`,category:["Hamburguerias","Pizzarias","Restaurantes","Clínicas","Barbearias","Mercados"][Math.floor(i/100)],style:templateNames[Math.floor(i/60)],variant:(i%60)+1,description:"Modelo Studio Sites"}));}
 return catalogCache;
}
function renderTemplateCards(){
 const root=$("#template-results");if(!root)return;
 const all=catalogCache||[]; const q=catalogQuery.toLowerCase(); const filtered=all.filter(m=>(catalogCategory==="Todos"||m.category===catalogCategory)&&(!q||`${m.id} ${m.category} ${m.style} ${m.description}`.toLowerCase().includes(q))); const pageSize=12; const total=Math.max(1,Math.ceil(filtered.length/pageSize));catalogPage=Math.min(Math.max(1,catalogPage),total);const rows=filtered.slice((catalogPage-1)*pageSize,catalogPage*pageSize);
 root.innerHTML=rows.map((m,i)=>`<article class="template-card"><div class="template-thumb" style="background-image:url('${imageUri((m.category||"").toLowerCase().replace(/s$/,""),m.variant||i+1)}');background-size:cover;background-position:center"><small>${esc(m.category)} · ${esc(m.style)}</small></div><div class="template-info"><b>${esc(m.category)} ${String(m.variant||i+1).padStart(2,"0")}</b><small>${esc(m.description||"Composição profissional criada para este estilo.")}</small><button class="btn soft" style="margin-top:12px;width:100%" data-template="${esc(m.style)}">Usar com IA</button></div></article>`).join("")||`<div class="feature" style="grid-column:1/-1"><h3>Nenhum modelo encontrado</h3><p>Tente outra busca ou categoria.</p></div>`;
 $("#template-count").textContent=`${filtered.length} modelos`; $("#template-page").textContent=`Página ${catalogPage} de ${total}`;$("[data-template-prev]")?.toggleAttribute("disabled",catalogPage<=1);$("[data-template-next]")?.toggleAttribute("disabled",catalogPage>=total);bind();
}
async function renderTemplates(){
 $("#main").innerHTML=`<section class="section"><div class="section-head"><div><div class="section-kicker">Biblioteca visual</div><h2>600 modelos para explorar.</h2><p>Use um modelo como ponto de partida. A IA pode mudar estrutura, conteúdo, imagens, estilo e seções depois.</p></div><span id="template-count" class="eyebrow">Carregando…</span></div><div class="catalog-toolbar"><input id="template-search" class="catalog-input" placeholder="Buscar modelo, categoria ou estilo…"><select id="template-category" class="catalog-input"><option>Todos</option><option>Hamburguerias</option><option>Pizzarias</option><option>Restaurantes</option><option>Clínicas</option><option>Barbearias</option><option>Mercados</option></select><button class="btn ghost" data-action="new">Criar do zero</button></div><div id="template-results" class="templates-grid"></div><div style="display:flex;align-items:center;justify-content:center;gap:12px;margin-top:22px"><button class="iconbtn" data-template-prev>←</button><span id="template-page" style="color:#8993a5;font-size:12px"></span><button class="iconbtn" data-template-next>→</button></div></section>`;
 const data=await getCatalog();renderTemplateCards();const search=$("#template-search"),cat=$("#template-category");search.oninput=()=>{catalogQuery=search.value;catalogPage=1;renderTemplateCards()};cat.onchange=()=>{catalogCategory=cat.value;catalogPage=1;renderTemplateCards()};$("[data-template-prev]").onclick=()=>{catalogPage--;renderTemplateCards()};$("[data-template-next]").onclick=()=>{catalogPage++;renderTemplateCards()};
}
function render(view="home"){
 document.body.innerHTML=page(view);
 if(view==="home")renderHome(); if(view==="creator")renderCreator();if(view==="projects")renderProjects();if(view==="templates")renderTemplates().catch(e=>{console.error("Studio Sites catalog error:",e);$("#main").innerHTML=`<section class="section"><div class="feature"><h3>Biblioteca temporariamente indisponível</h3><p>O restante do Studio Sites continua funcionando normalmente.</p></div></section>`});
 bind();
}
function bind(){
 $$("[data-nav]").forEach(b=>b.onclick=()=>render(b.dataset.nav));
 $$("[data-action=new]").forEach(b=>b.onclick=()=>{let p=fresh();p.name="Novo projeto";p.updatedAt=new Date().toISOString();addProject(p);state.messages=[{role:"ai",text:"Perfeito. Que site você quer criar? Pode escrever normalmente, por exemplo: “quero uma pizzaria moderna com fotos e WhatsApp”."}];save();render("creator")});
 $$("[data-open]").forEach(b=>b.onclick=()=>{state.current=b.dataset.open;state.messages=[{role:"ai",text:"Projeto aberto. O que você quer alterar?"}];save();render("creator")});
 $$("[data-template]").forEach(b=>b.onclick=()=>{let p=current()||fresh();p.style=b.dataset.template;p.updatedAt=new Date().toISOString();if(!current())addProject(p);else save();state.messages=state.messages||[];state.messages.push({role:"ai",text:`Estilo ${b.dataset.template} aplicado. Agora me diga o que você quer criar ou alterar.`});save();render("creator")});
 const send=()=>{let el=$("#prompt"),raw=el?.value.trim();if(!raw)return;addMsg("user",raw);el.value="";let ans=applyAI(raw);addMsg("ai",ans);render("creator")};
 const sendBtn=$("[data-action=send]"); if(sendBtn)sendBtn.onclick=send;
 const ta=$("#prompt");if(ta)ta.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
 $$("[data-prompt]").forEach(b=>b.onclick=()=>{if($("#prompt")){$("#prompt").value=b.dataset.prompt;$("#prompt").focus()}});
 $$("[data-action=clear-chat]").forEach(b=>b.onclick=()=>{state.messages=[{role:"ai",text:"Conversa limpa. O projeto continua salvo. O que você quer fazer agora?"}];save();render("creator")});
 $$("[data-action=undo]").forEach(b=>b.onclick=()=>{if(!state.history.length)return toast("Nada para desfazer.");let p=current();state.future.push(JSON.stringify(p));Object.assign(p,JSON.parse(state.history.pop()));save();render("creator");toast("Alteração desfeita.")});
 $$("[data-action=redo]").forEach(b=>b.onclick=()=>{if(!state.future.length)return toast("Nada para refazer.");let p=current();state.history.push(JSON.stringify(p));Object.assign(p,JSON.parse(state.future.pop()));save();render("creator");toast("Alteração refeita.")});
 $$(["[data-action=fullscreen]","[data-action=mobile-nav]"]).forEach(()=>{}); $$(["[data-action=fullscreen]"]).forEach(b=>b.onclick=()=>{$(".site-frame")?.requestFullscreen?.()}); $$(["[data-action=mobile-nav]"]).forEach(b=>b.onclick=()=>{const n=$(".nav"); if(n){n.style.display=n.style.display==="flex"?"none":"flex";n.style.position="absolute";n.style.top="66px";n.style.left="12px";n.style.right="12px";n.style.flexDirection="column";n.style.padding="8px";n.style.background="#11151d";n.style.border="1px solid rgba(255,255,255,.1)";n.style.borderRadius="14px";n.style.boxShadow="0 20px 50px rgba(0,0,0,.4)";}});
 $$("[data-action=download-zip]").forEach(b=>b.onclick=downloadZip);
 $$("[data-action=pdf]").forEach(b=>b.onclick=downloadPdf);
}
function buildSiteHTML(p){const css=`.site-preview{font-family:Arial,sans-serif;color:#111}.site-header{height:68px;padding:0 7%;display:flex;align-items:center;gap:30px;border-bottom:1px solid #ddd}.site-logo{font-weight:800}.site-nav{display:flex;gap:22px;margin-left:auto;font-size:13px}.site-cta,.site-btn{padding:11px 15px;border-radius:10px;background:#111;color:#fff;text-decoration:none;font-weight:700}.site-main{background:var(--site-bg,#fff);color:var(--site-text,#111)}.site-hero{padding:70px 7%;display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center}.site-hero h1{font-size:52px;line-height:1;margin:0 0 16px}.site-hero p,.site-section>p{line-height:1.6;color:#68707b}.site-visual,.card-image{min-height:220px;border-radius:20px;background:linear-gradient(135deg,#222,#8b5a3c)}.site-section{padding:60px 7%}.site-section.alt{background:var(--site-surface,#f6f6f4)}.site-section h2{text-align:center;font-size:32px}.site-grid,.testimonials{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.site-card,.quote,.contact-box{border:1px solid #ddd;border-radius:15px;overflow:hidden;background:#fff}.card-body,.quote,.contact-box{padding:16px}.site-contact{display:grid;grid-template-columns:1fr 1fr;gap:25px}.site-footer{padding:28px 7%;display:flex;justify-content:space-between;border-top:1px solid #ddd;color:#68707b}@media(max-width:700px){.site-hero,.site-contact{grid-template-columns:1fr}.site-grid,.testimonials{grid-template-columns:1fr}.site-nav{display:none}.site-hero h1{font-size:40px}}`;return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(p.name)}</title><style>${css}</style></head><body>${renderSite(p)}</body></html>`}
function downloadBlob(blob,name){let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500)}
function downloadZip(){
 const p=current();if(!p)return toast("Crie um projeto primeiro.");
 // Self-contained ZIP writer using stored (uncompressed) files and CRC32.
 const files=[["index.html",buildSiteHTML(p)],["images/hero.svg",imageSvg(p.category,1)],["images/card-01.svg",imageSvg(p.category,2)],["images/card-02.svg",imageSvg(p.category,3)],["images/card-03.svg",imageSvg(p.category,4)],["assets/README.txt","Assets gerados localmente pelo Studio Sites."],["README.txt","Site exportado pelo Studio Sites. Abra index.html ou publique a pasta em GitHub Pages."]];
 const crcTable=(()=>{let t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
 const crc32=u8=>{let c=0xffffffff;for(const b of u8)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0};
 const enc=new TextEncoder(),chunks=[],central=[];let off=0;
 const u16=n=>new Uint8Array([n&255,n>>>8&255]),u32=n=>new Uint8Array([n&255,n>>>8&255,n>>>16&255,n>>>24&255]);
 const cat=(...a)=>{let n=a.reduce((s,x)=>s+x.length,0),o=new Uint8Array(n),i=0;a.forEach(x=>{o.set(x,i);i+=x.length});return o};
 files.forEach(([name,data])=>{let nb=enc.encode(name),db=enc.encode(data),c=crc32(db);let h=cat(new Uint8Array([80,75,3,4,20,0,0,0,0,0,0,0,0,0]),u32(c),u32(db.length),u32(db.length),u16(nb.length),u16(0),nb,db);chunks.push(h);central.push({nb,c,len:db.length,off});off+=h.length});
 let cdOff=off;let cds=central.map(x=>cat(new Uint8Array([80,75,1,2,20,0,20,0,0,0,0,0,0,0,0,0]),u32(x.c),u32(x.len),u32(x.len),u16(x.nb.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(x.off),x.nb));let cd=cat(...cds);let end=cat(new Uint8Array([80,75,5,6,0,0,0,0]),u16(files.length),u16(files.length),u32(cd.length),u32(cdOff),u16(0));downloadBlob(new Blob([cat(...chunks,cd,end)],{type:"application/zip"}),`${slug(p.name)}.zip`);toast("ZIP criado.");
}
function downloadPdf(){
 const p=current();if(!p)return toast("Crie um projeto primeiro.");
 const d=siteData(p);
 const ascii=v=>String(v??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^\x20-\x7E]/g,"").slice(0,120);
 const lines=[ascii(p.name||d[0]),ascii(d[1]),"DESTAQUES",ascii(d[4]),ascii(d[5]),ascii(d[6])];
 const contact=[p.whatsapp?`WhatsApp: ${p.whatsapp}`:"WhatsApp: nao informado",p.instagram?`Instagram: @${p.instagram}`:"Instagram: nao informado",p.address?`Endereco: ${p.address}`:"Endereco: nao informado"].map(ascii);
 const q=s=>String(s).replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
 let content="q 0.96 0.97 0.99 rg 0 0 595 842 re f Q\n";
 content+="q 0.43 0.32 0.95 rg 48 742 499 5 re f Q\n0 0 0 rg\nBT /F1 30 Tf 48 690 Td ("+q(lines[0])+") Tj\n/F1 13 Tf 0 -28 Td ("+q(lines[1])+") Tj\nET\n";
 content+="q 0.91 0.90 0.98 rg 48 470 499 150 re f Q\n0 0 0 rg\nBT /F1 18 Tf 70 585 Td (DESTAQUES) Tj\n/F1 13 Tf 0 -32 Td ("+q(lines[3])+") Tj\n0 -24 Td ("+q(lines[4])+") Tj\n0 -24 Td ("+q(lines[5])+") Tj\nET\n";
 content+="q 0.93 0.94 0.96 rg 48 275 499 145 re f Q\n0 0 0 rg\nBT /F1 16 Tf 70 385 Td (CONTATO) Tj\n/F1 12 Tf 0 -28 Td ("+q(contact[0])+") Tj\n0 -22 Td ("+q(contact[1])+") Tj\n0 -22 Td ("+q(contact[2])+") Tj\nET\n";
 content+="0.35 0.38 0.44 rg\nBT /F1 10 Tf 48 48 Td (Apresentacao criada pelo STUDIO SITES) Tj ET\n";
 const enc=new TextEncoder();
 const objects=["<< /Type /Catalog /Pages 2 0 R >>","<< /Type /Pages /Kids [3 0 R] /Count 1 >>","<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>","<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",`<< /Length ${enc.encode(content).length} >>\nstream\n${content}endstream`];
 const chunks=[];let offset=0;const offsets=[0];const header=enc.encode("%PDF-1.4\n");chunks.push(header);offset=header.length;
 objects.forEach((obj,i)=>{const bytes=enc.encode(`${i+1} 0 obj\n${obj}\nendobj\n`);offsets.push(offset);chunks.push(bytes);offset+=bytes.length});
 const xrefOffset=offset;let xref=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;for(let i=1;i<offsets.length;i++)xref+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";xref+=`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
 chunks.push(enc.encode(xref));downloadBlob(new Blob(chunks,{type:"application/pdf"}),`${slug(p.name)}.pdf`);toast("PDF criado.");
}
function showFallback(){
 const host=document.getElementById("app");
 if(host)host.innerHTML=`<header class="topbar"><div class="logo">STUDIO SITES</div><div class="top-actions"><button class="btn primary" onclick="location.reload()">Recarregar</button></div></header><main><section class="hero"><div><span class="eyebrow">✦ Studio Sites</span><h1>Crie sites profissionais com IA.</h1><p>Descreva o site que você quer e a IA constrói tudo para você.</p><div class="hero-actions"><button class="btn primary" onclick="location.reload()">Começar agora →</button></div></div></section></main>`;
}
window.addEventListener("error",e=>{console.error("Studio Sites runtime error:",e.error||e.message); if(document.getElementById("main") && !document.getElementById("main").children.length)showFallback();});
window.addEventListener("unhandledrejection",e=>{console.error("Studio Sites async error:",e.reason);});
window.addEventListener("load",()=>{try{render("home")}catch(e){console.error("Studio Sites boot error:",e);showFallback()}});
})();
