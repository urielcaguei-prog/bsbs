# STUDIO SITES — relatório de correção

## Problema observado
A versão mostrada no celular parecia HTML puro porque a primeira pintura dependia do CSS/JavaScript e a interface dinâmica podia substituir o HTML inicial. Também havia bindings e regexes frágeis no JavaScript.

## Correções aplicadas
- Interface inicial agora existe em HTML real antes do JavaScript.
- CSS profissional foi embutido no `index.html` como fallback crítico; `assets/styles.css` continua disponível.
- Removida dependência obrigatória de fonte externa: a tipografia usa stack moderna local.
- Header, hero, cards, chat, preview, catálogo, botões e formulários receberam identidade visual completa.
- Mobile foi tratado como prioridade, sem navegação padrão do navegador.
- Adicionado menu mobile.
- Preview usa visuais SVG gerados localmente, sem imagens externas obrigatórias.
- Catálogo local lê `assets/models-600.json` e usa paginação de 12 modelos, busca e filtro por categoria.
- Mantidos 600 modelos: 6 categorias × 10 estilos × 10 variações.
- Corrigidas regexes de WhatsApp, nome, Instagram e normalização de erros de digitação.
- Reconhecimento de `pizaria`, `pizzariaa`, `renover`, `preco`, `whats`, `zap`, `img`, `imgs`.
- Reconhecimento de `fundão preto` e variações de linguagem informal.
- Contatos não são inventados; WhatsApp só vira link quando o número é informado.
- Contatos adicionais: Instagram, Facebook, TikTok, YouTube, Telegram, Threads, X, LinkedIn, Pinterest, Discord, e-mail, telefone e localização.
- Undo/Redo e localStorage preservados.
- Exportação ZIP corrigida: o arquivo agora é um ZIP estruturalmente válido com `index.html`, `images/`, `assets/` e README.
- Exportação PDF corrigida para um PDF 1.4 válido com apresentação visual, destaques e contatos.
- Falhas de catálogo/funcionalidades secundárias não devem substituir a página inteira por uma tela vazia.
- `.nojekyll` mantido para GitHub Pages.

## Testes executados
- `node --check assets/app.js` — OK.
- HTTP local: `index.html`, CSS, JS e `models-600.json` — HTTP 200.
- Renderização estática do HTML/CSS com WeasyPrint — OK; a primeira pintura é visualmente estilizada.
- Normalização e inferência local — OK.
- Cenários de IA testados: pizzaria, remoção de preços, remoção de imagens, fundo escuro, estilo premium/moderno, WhatsApp, Instagram, remoção de Instagram e troca de nome.
- Comando complexo testado; informações de contato sem dados fornecidos permanecem vazias, sem invenção.
- ZIP gerado em teste — validado com `unzip -t` sem erros; contém 7 arquivos.
- PDF gerado em teste — validado com `pdfinfo`; PDF 1.4, 1 página, sem JavaScript.

## Limitação de validação visual de navegador
O Chromium headless disponível neste ambiente não concluiu a inicialização por limitações do ambiente (DBus/zygote). Por isso não foi declarado um teste de interação de navegador real como concluído. A validação disponível foi feita por análise estática, execução JavaScript em VM, servidor HTTP local e validação real dos arquivos exportados.
